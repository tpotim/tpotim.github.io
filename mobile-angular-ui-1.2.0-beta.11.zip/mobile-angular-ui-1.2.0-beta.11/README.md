# Mobile Angular UI

## Angular &amp; Bootstrap 3 for Mobile web and applications

Mobile Angular UI is an HTML5 mobile UI framework that will let you use Angular Js and Bootstrap 3 for mobile app development.

GettingStarted, Demo, Docs at http://mobileangularui.com.

![](http://mobileangularui.com/assets/img/phone.png)

### Support development

<a href='https://pledgie.com/campaigns/24868'><img alt='Click here to lend your support to: Mobile Angular UI and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/24868.png?skin_name=chrome' border='0' ></a>

Released Under [MIT License](https://github.com/mcasimir/mobile-angular-ui/blob/master/LICENSE).
