describe("Switch with $swipe", function() {
  it("should handle swipe if $swipe service is present", function() {
    
  });
});