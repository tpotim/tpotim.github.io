$(document).ready(function () {
	$(".mouseover-index").on( "mouseover", function() {
		$(".mouseover-index").each(function(){
			$(this).find(".pull-left").each(function(){
				if($(this).hasClass("small-img")){
					$(this).addClass("hide");
				}
				if($(this).hasClass("index-middle-item-text")){
					$(this).addClass("index-middle-item-text1").removeClass("index-middle-item-text");
					$(this).find("a").addClass("link-grey-font12").removeClass("link-grey-font14");
				}
				if($(this).hasClass("red-label-no-round")){
					$(this).addClass("grey-label-no-round").removeClass("red-label-no-round");
				}
			});
		});
		$(this).find(".pull-left").each(function(){
			if($(this).hasClass("small-img")){
				$(this).removeClass("hide");
			}
			if($(this).hasClass("index-middle-item-text1")){
				$(this).removeClass("index-middle-item-text1").addClass("index-middle-item-text");
				$(this).find("a").removeClass("link-grey-font12").addClass("link-grey-font14");
			}
			if($(this).hasClass("grey-label-no-round")){
				$(this).addClass("red-label-no-round").removeClass("grey-label-no-round");
			}
			
		});
	});

	$(".mouseover-index1").on( "mouseover", function() {
		$(".mouseover-index1").each(function(){
			$(this).find(".pull-left").each(function(){
				if($(this).hasClass("small-img")){
					$(this).addClass("hide");
				}
				if($(this).hasClass("index-middle-item-text")){
					$(this).addClass("index-middle-item-text1").removeClass("index-middle-item-text");
					$(this).find("a").addClass("link-grey-font12").removeClass("link-grey-font14");
				}
				if($(this).hasClass("red-label-no-round")){
					$(this).addClass("grey-label-no-round").removeClass("red-label-no-round");
				}
			});
		});
		$(this).find(".pull-left").each(function(){
			if($(this).hasClass("small-img")){
				$(this).removeClass("hide");
			}
			if($(this).hasClass("index-middle-item-text1")){
				$(this).removeClass("index-middle-item-text1").addClass("index-middle-item-text");
				$(this).find("a").removeClass("link-grey-font12").addClass("link-grey-font14");
			}
			if($(this).hasClass("grey-label-no-round")){
				$(this).addClass("red-label-no-round").removeClass("grey-label-no-round");
			}
		});
	});

	$(".mouseover-index2").on( "mouseover", function() {
		$(".mouseover-index2").each(function(){
			$(this).find(".pull-left").each(function(){
				if($(this).hasClass("small-img")){
					$(this).addClass("hide");
				}
				if($(this).hasClass("index-middle-item-text2")){
					$(this).addClass("index-middle-item-text1").removeClass("index-middle-item-text2");
					$(this).find("a").addClass("link-grey-font12").removeClass("link-grey-font14");
				}
				if($(this).hasClass("red-label-no-round")){
					$(this).addClass("grey-label-no-round").removeClass("red-label-no-round");
				}
			});
		});
		$(this).find(".pull-left").each(function(){
			if($(this).hasClass("small-img")){
				$(this).removeClass("hide");
			}
			if($(this).hasClass("index-middle-item-text1")){
				$(this).removeClass("index-middle-item-text1").addClass("index-middle-item-text2");
				$(this).find("a").removeClass("link-grey-font12").addClass("link-grey-font14");
			}
			if($(this).hasClass("grey-label-no-round")){
				$(this).addClass("red-label-no-round").removeClass("grey-label-no-round");
			}
		});
	});
	

	$(".time-choose").on( "click", function() {
		$(".time-choose").removeClass("time-item-active").addClass("time-item");		
		$(".upline").css("width",($(this).width())+"px").css("left",($(this).position().left)+"px");
		$(this).removeClass("time-item").addClass("time-item-active");
		$(".upline").show();
	});

	$(".time-choose").on( "mouseover", function() {
		$(".time-choose").css("background-color","#fff");
		$(this).css("background-color","#f5f5f5");
	});

	$(".time-choose").on( "mouseout", function() {
		$(this).css("background-color","#fff");
	});

	$("#myCarousel").append('<div class="upline"></div>');
	
	$(".set-order-btn").on( "click", function() {
		$(".set-order-btn").removeClass("active");
		$(this).addClass("active");
	});

	$(".experience-item").on( "mouseover", function() {
		$(this).css({
			"background-color":"#f5f5f5"
		});
		$(this).find(".download-btns").removeClass("hide");
	});

	$(".experience-item").on( "mouseout", function() {
		$(".experience-item").css({
			"background-color":"#fff"
		});
		$(".download-btns").addClass("hide");
	});

	$(".search-content-item").on( "mouseover", function() {
		$(this).css({
			"background-color":"#f5f5f5"
		});
		$(this).find(".download-btns").removeClass("hide");
	});

	$(".search-content-item").on( "mouseout", function() {
		$(".search-content-item").css({
			"background-color":"#fff"
		});
		$(".download-btns").addClass("hide");
	});

	$(".item-choose").on( "click", function() {
		$(".item-choose").removeClass("small-item-active").addClass("small-item");
		$(".upline").css("width",($(this).width())+"px").css("left",($(this).position().left)+"px");
		$(this).removeClass("small-item").addClass("small-item-active");
		$(".upline").show();
	});

	$(".item-choose").on( "mouseover", function() {
		$(".item-choose").css("background-color","#fff");
		$(this).css("background-color","#f5f5f5");
	});

	$(".item-choose").on( "mouseout", function() {
		$(this).css("background-color","#fff");
	});

	$(".email-me-1").on( "click", function() {
		$("#emailMe").modal("show");
	});

	$(".detail-video-email").on( "click", function() {
		$("#emailMe").modal("show");
	});
	
	$('.datepicker tbody').on('click', function(){  $('.datepicker').hide() });

	var position = $(".pagination-part").offset();
	if(position!=undefined){
		$(window).scroll(function(){
	        $('.datepicker').hide();
	        $('#from').trigger("blur");
	        if($(window).scrollTop() + $(window).height() > $(document).height() - 200 || $(window).scrollTop() > position.top - 200) {
	       		$(".loading").removeClass("hide");
	   		}
    	});
	}
	var nowTemp = new Date();
    var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
    var strDate = nowTemp.getFullYear() + "-" + (nowTemp.getMonth()+1) + "-" + nowTemp.getDate(); 
    var endTemp = new Date(nowTemp.getTime() + 24 * 60 * 60 * 1000);
    var endDate = endTemp.getFullYear() + "-" + (endTemp.getMonth()+1) + "-" + endTemp.getDate(); 
    $('#from').val(strDate);
    $("#to").val(endDate);
    var checkin = $('#from').datepicker({
    	format: 'yyyy-mm-dd',
	    onRender: function(date) {
	    return date.valueOf() < now.valueOf() ? 'disabled' : '';
    	}
    }).on('changeDate', function(ev) {
	    if (ev.date.valueOf() >= checkout.date.valueOf()) {
	    var newDate = new Date(ev.date)
	    newDate.setDate(newDate.getDate() + 1);
	    checkout.setValue(newDate);
	    }
	    checkin.hide();
	    $('#dpd2')[0].focus();
    }).data('datepicker');
    var checkout = $('#to').datepicker({
    	format: 'yyyy-mm-dd',
	    onRender: function(date) {
	    return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
	    }
    }).on('changeDate', function(ev) {
    	checkout.hide();
    }).data('datepicker');


 	$(".index-bbs-item:eq("+($(".index-bbs-item").length-1)+")").css('margin-bottom','0px');

 	$(".play-video").on( "mouseover", function() {
 		$(this).attr("src","images/play.png");
 	});

 	$(".play-video").on( "mouseout", function() {
 		$(this).attr("src","images/play_normal.png");
 	});

 	$(".play-video").on( "click", function() {
 		$("#play-video").modal('show')
 	});

 	$(".carousel-control").on("click",function(){
 		$(".time-choose").removeClass("time-item-active").addClass("time-item");	
 		$(".item-choose").removeClass("small-item-active").addClass("small-item");
 		$(".upline").hide();
 	});

 	if($(".index-big-banner").has("img").length!=0){
 		$(".normal-header").css("border","0px");
 	}

 	$(".index-hot-right-grey").on("mouseover", function() {
 		$(".follow-icon").attr("src","images/follow_icon_1.png");
 		$(".follow-me").removeClass("hide");
 	});

 	$(".index-hot-right-grey").on("mouseout", function() {
 		$(".follow-icon").attr("src","images/follow_icon_0.png");
 		$(".follow-me").addClass("hide");
 	});

 	//set in php
 	$(".time-choose:eq(0)").trigger("click");
	$(".item-choose:eq(0)").trigger("click");

});